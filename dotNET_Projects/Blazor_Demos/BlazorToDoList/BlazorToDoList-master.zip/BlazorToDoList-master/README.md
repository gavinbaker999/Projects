# Blazor To-Do List

This example project creates a [Blazor](https://dotnet.microsoft.com/apps/aspnet/web-apps/client) application and uses it to create and manage a To-Do list of items.  This project is used in the following blog posts:


### [Using Blazor to Build a Client-Side Single-Page App with .NET Core](https://exceptionnotfound.net/using-blazor-to-build-a-client-side-single-page-app-with-net-core/)
